<!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
            class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Mobil</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>On</th>
                        <th>Off</th>
                        <th>Ack</th>
                        <th>Dis By</th>
                        <th>Reason</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>On</th>
                        <th>Off</th>
                        <th>Ack</th>
                        <th>Dis By</th>
                        <th>Reason</th>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div> -->
                    <tr>
                        <td>1</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>2011/04/25</td>
                        <td>2011/04/25</td>
                        <td>Edinburgh</td>
                        <td>Tiger Nixon</td>
                        <td>Interlock Hose Reel Front</td>
                    </tr>
              