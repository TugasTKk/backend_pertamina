<?php

namespace App\Models;

use CodeIgniter\Model;

class DataMobilModel extends Model
{
    protected $DBGroup              = 'default';
    protected $table                = 'datamobil';
    protected $primaryKey           = 'id';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDeletes       = false;
    protected $protectFields        = true;
    protected $allowedFields        = ["id_mobil","time_on", "time_off", "action", "dismiss", "reason", 'reason_detail'];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    
    public function __construct()
    {
        parent::__construct();
        // $this->db = \Config\Database::connect();
        $this->db = db_connect();
    }

    public function getAllDataMobil(){
        // $db      = \Config\Database::connect();
        $query = "SELECT datamobil.id,id_mobil,time_on, time_off, 'action', reason, reason_detail, email, nama, (SELECT GROUP_CONCAT(nama) FROM users WHERE users.id != datamobil.action) as personDismiss FROM `datamobil` JOIN users ON datamobil.action = users.id where time_on BETWEEN date_sub(now(), INTERVAL 2 WEEK) and now()";
        $res = $this->db->query($query);
        return $res->getResult();
    }

    function getAllDataMobilById($id = -1){
        $query = "SELECT *, (SELECT GROUP_CONCAT(nama) FROM users WHERE users.id != datamobil.action) as personDismiss FROM `datamobil` JOIN users ON datamobil.action = users.id where datamobil.id_mobil='".$id."' AND time_on BETWEEN date_sub(now(), INTERVAL 2 WEEK) and now()";
        $res = $this->db->query($query);
        return $res->getResult();
    }

    function getReasonGraph(){
        $query = "SELECT reason,COUNT(id) as jumlah, reason_detail, time_on FROM datamobil WHERE time_on BETWEEN date_sub(now(), INTERVAL 2 WEEK) and now() GROUP BY reason";
        $res = $this->db->query($query);
        return $res->getResult();
    }

    function updateAction($data){
        $query = "UPDATE datamobil SET reason = '".$data['parameter']."', reason_detail = '".$data['checkedValue']."', action= CASE WHEN action IS NULL || `action`='' THEN '".$data['id']."' WHEN action IS NOT NULL THEN action END WHERE id_mobil = '".$data['parameterMobil']."' ORDER BY id DESC LIMIT 1";
        $res = $this->db->query($query);
    }
    
    function cekBefore($id = -1){
        $query = "SELECT * FROM datamobil WHERE id_mobil='".$id."' and time_off IS NULL";
        $res = $this->db->query($query);
        return $res->getNumRows();
    }
    
    function updateTimeOff($id = -1){
        $query = "UPDATE datamobil set time_off = CURRENT_TIMESTAMP() where id_mobil='".$id."' and time_off IS NULL";
        $res = $this->db->query($query);
    }
    
    function insertMobil($data){
        $query = "INSERT INTO datamobil (id_mobil,time_on) VALUES ('".$data['id_mobil']."',CURRENT_TIMESTAMP())";
        $res = $this->db->query($query);
    }
}
